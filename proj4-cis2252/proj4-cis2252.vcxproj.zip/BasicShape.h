#include <iostream>
#include <vector>
#include <string>
#ifndef _BASICSHAPE
#define _BASICSHAPE
#define PI 3.141

using namespace std;
 
//c++ version of interface 
class BasicShape
{
public:
	//pure virtual funtion that returns the shape type 
	virtual string whatAmI() = 0;
	//pure virtual function that returns the area of shape type
	virtual double getArea() = 0; 
};//end BasicShape

//********************************************************************//
//implement methods for circle object data
class Circle : public BasicShape
{
public:

	//getter / setters 
	void setCircumference(double radius);
	double getCircumference(void);

	//constructor
	Circle(const double &radius) : mradius(radius){}

	//override to return Circle Type
	string whatAmI() override{ return "Circle"; }

	//Area logic from Radius to Circumfrence 
	double getArea() override { return getCircumference()*2*PI;}
	
private:
	double mradius; 
};//end Circle

//**********************************************************************//
void Circle::setCircumference(double radius)
{
	mradius = radius; 
}
double Circle::getCircumference(void)
{
	return mradius;
}

//***********************************************************************//
//implements methods for rectangle object data 
class Rectangle : public BasicShape
{
	
public:

	//getter / setter 
	void setPerimeter(double mlength, double mwidth);
	double getPerimeter(void);

	// constructor for Rectangle Ojects
	Rectangle(const double& length , const double &width) : mlength(length), mwidth(width) {};

	//Override to return Rectangle Type
	string whatAmI() override { return "Rectangle"; }

	//Override and logic for Area from obtaining a Perimeter 
	double getArea() override { return getPerimeter()*2; }

private:
	double mlength;
	double mwidth;

};//end rectangle

void Rectangle::setPerimeter(double length, double width)
{
	mlength = length;
	mwidth = width;
}
//logic for perimeter 
double Rectangle::getPerimeter(void)
{
	return (mlength + mwidth);
}

#endif //!= +BASICSHAPE


//**********************************************************************//

int main()
{
	
	int i;
	//creates BasicShape Objects with their attributes 
	for (i = 0; i < 10; i++)
	{
		BasicShape* basic1 = new BasicShape();
	}

	

	//creates vector of pointers to BasicShape Class
	vector<BasicShape*> *shapePtr = new vector<BasicShape*>();
	//itterates through pointer vector and prints out function calls 
	vector<BasicShape*>::iterator it;
	for (it = shapePtr->begin(); it != shapePtr->end(); ++it)
	{
		cout << (*it)->whatAmI() << endl;
		cout << (*it)->getArea() << endl; 
	}

	delete shapePtr;
	shapePtr = NULL; 


	return 0;
}//end main 


